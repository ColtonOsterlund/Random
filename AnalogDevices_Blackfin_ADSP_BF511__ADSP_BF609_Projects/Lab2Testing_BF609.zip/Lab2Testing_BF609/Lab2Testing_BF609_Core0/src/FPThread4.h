/*
 * FPThread4.h
 *
 *  Created on: Oct 29, 2019
 *      Author: kfrie
 */

#ifndef FPTHREAD4_H_
#define FPTHREAD4_H_

#include "../../../ENCM511_SpecificFiles/ENCM511_include/FrontPanel_LED_Switches.h"
//#include "uTTCOS_Lab2_BF609_Core0_uTTCOSg2017_main.h"

void TaskFPThread4(void);

#endif /* FPTHREAD4_H_ */
