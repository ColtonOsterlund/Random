/*************************************************************************************
* AUTO-GENERATED COMMENT - DO NOT MODIFY 
* Author: kfrie 
* Date: Tue 2019/10/29 at 02:16:57 PM 
* File Type: TTCOS Main File
*************************************************************************************/

// This is an example TT_COS main( ) function with threads.
// Use this as a template for your own TT_COS main( ) for the various Threads

#include "uTTCOS_Lab2_BF609_Core0_uTTCOSg2017_main.h"
#include "../../../ENCM511_SpecificFiles/ENCM511_include/FrontPanel_LED_Switches.h"
// TODO -- Update this code to use CORETIMER interrupts to allow slow uTTCOS in BF533 simulator
// TODO Just these values so that 100 TICS tacks about 1 second
#if defined(__ADSPBF609__)
#define  TIC_CONTROL_VALUE ((unsigned long int) 4800000)		// BF609 EMULATOR
#define TICS_PER_SECOND 	100
#define ONE_SECOND 			TICS_PER_SECOND		// If TICS_CONTROL_VALUE Adjusted correctly
#define RUN_ONCE			0
#define NO_DELAY			0
#else
#error "Unknown ADSP or ARM processor"
#endif


float Lab0RuntimeFraction = 1;
static int numSecondsSW1Held = 0;
static unsigned short int arrayValues[100] = {0};
static int REBArrayLength = 0;

void main(void) {
	// Make maxNumberThreads at least 5 larger than the 
	//            number of threads you plan to add
	int numBackgroundThreads = 5;
	int numberYourThreads = 8;
	int maxNumberThreads = numBackgroundThreads + numberYourThreads;
// initialize the front panel LED and Switches
	Init_GPIO_FrontPanelSwitches();
	Init_GPIO_FrontPanelLEDS();
	My_Init_REB_GPIO_ASM();

	Custom_uTTCOS_OS_Init(TIC_CONTROL_VALUE);  // Need to update to handle coretimer interrupts
#if 0
	// TODO -- Remove this TODO statement and next line when demo is finished and you start your Lab 2
	Set_Up_NOT_START_RemoveMeSoonTasks( );
#endif

	createThreads();

#warning "You will need to activate the next line to start the uTTCOS Clock scheduler
	uTTCOSg_Start_CoreTimer_Scheduler(maxNumberThreads);   //  Start the scheduler timer
				// Execution time of TT_COS_Dispatch( ) and TT_COS_Update( ) improved by specifiying maxNumberTasks
	while (1) {

		// Wait, in low power mode, for an interrupt
		// The interrupt service routine calls TTCOS_Update( )
		// uTTCOSg_GoToSleep( );                // Need to update to handle coretimer interrupts
		Idle_WaitForInterrupts_ASM( );

		// Run all the threads in the system according
		// to whether their delays have expired
		uTTCOSg_DispatchThreads( );
	}
}

extern volatile char ID_FPThread1;
extern volatile char ID_FPThread2;
extern volatile char ID_FPThread3;
extern volatile char ID_FPThread4;
extern volatile char ID_FPThread5;
extern volatile char ID_REBThread1;
extern volatile char ID_REBThread2;
extern volatile char ID_REBThread3;
extern volatile char ID_CheckSW2PressedReleasedThread;
extern volatile char ID_StopCheckSW2PressedReleasedThread;
extern volatile char ID_CheckSW1PressedReleasedThread;
extern volatile char ID_CountSecondsSW1PressedThread;
extern volatile char ID_ChangeFPThread5SpeedThread;
extern volatile char ID_CheckSW5PressedReleased;
extern volatile char ID_StoreSwitchValuesInArrayThread;
extern volatile char ID_CheckSW3PressedReleasedThread;
extern volatile char ID_REBThread3;

void createThreads(void){
	ID_FPThread1 = uTTCOSg_AddThread(Task_FPThread1, NO_DELAY, 0.25 * ONE_SECOND); //need to switch LED every .25 seconds
	ID_FPThread2 = uTTCOSg_AddThread(TaskFPThread2, NO_DELAY, 0.33 * (1.2 * ONE_SECOND));
	ID_FPThread3 = uTTCOSg_AddThread(TaskFPThread3, NO_DELAY, 0.5 * ONE_SECOND);
	ID_CheckSW2PressedReleasedThread = uTTCOSg_AddThread(CheckSW2PressedReleasedThread, NO_DELAY, 0.1 * ONE_SECOND); //checks state of button every 10th of a second
	ID_REBThread1 = uTTCOSg_AddThread(TaskREBThread1, NO_DELAY, 0.25 * ONE_SECOND);
	ID_CheckSW1PressedReleasedThread = uTTCOSg_AddThread(CheckSW1PressedReleasedThread, NO_DELAY, 0.1 * ONE_SECOND);
	ID_CheckSW5PressedReleased = uTTCOSg_AddThread(CheckSW5PressedReleased, NO_DELAY, 0.1 * ONE_SECOND);
	ID_CheckSW3PressedReleasedThread = uTTCOSg_AddThread(CheckSW3PressedReleased, NO_DELAY, 0.1 * ONE_SECOND);
}

extern volatile char ID_CheckSW2PressedReleasedThread = 0;
void CheckSW2PressedReleasedThread(void){
	static int SW2State = 0;

	unsigned char FPLEDValue = ~Read_GPIO_FrontPanelSwitches();
	unsigned char SW2Value = FPLEDValue & 0x02; //get value of SW2 only
	SW2Value = SW2Value >> 1; //SW2Value will be 1 if SW2 was on and 0 if SW2 was off

	if(SW2Value == 0 && SW2State == 1){ //was previously on and now is off
		//START SHOW LAB 0 THREAD FROM THIS THREAD & THEN STOP THIS THREAD AT THE BEGINNING OF SHOW LAB 0 THREAD
		//AND RESTART IT AT THE END OF SHOW LAB 0 THREAD
		//ID_DisplayLab0Thread = uTTCOSg_AddThread(Task_DisplayLab0Thread, NO_DELAY, RUN_ONCE); //start the ID_DisplayLab0Thread and run only once
		ID_FPThread4 = uTTCOSg_AddThread(TaskFPThread4, NO_DELAY, Lab0RuntimeFraction * ONE_SECOND); //initially runs every 1 second - the LAB_0_RUNTIME_FRACTION will be changed in FPThread5
		ID_StopCheckSW2PressedReleasedThread = uTTCOSg_AddThread(StopCheckSW2PressedAndReleasedThread, NO_DELAY, RUN_ONCE); //stop checking SW2 pressed and released
	}

	SW2State = SW2Value;
	//printf("\n\n%d\n\n", SW2State);
}

extern volatile char ID_StopCheckSW2PressedReleasedThread = 0;
void StopCheckSW2PressedAndReleasedThread(void){
	uTTCOSg_DeleteThread(ID_CheckSW2PressedReleasedThread);
}

extern volatile char ID_CheckSW1PressedReleasedThread = 0;
void CheckSW1PressedReleasedThread(void){
	static int SW1State = 0;
	unsigned char FPLEDValue = ~Read_GPIO_FrontPanelSwitches();
	unsigned char SW1Value = FPLEDValue & 0x01; //get value of SW2 only

	if(SW1Value == 1 && SW1State == 0){ //was previously off and now is on
		//start thread to count time that it is pressed down (using static variable)
		ID_CountSecondsSW1PressedThread = uTTCOSg_AddThread(CountSecondsSW1PressedThread, ONE_SECOND, ONE_SECOND); //delay one second so that it starts counting in one second
	}

	if(SW1Value == 0 && SW1State == 1){ //was previously on and now is off
		uTTCOSg_DeleteThread(ID_CountSecondsSW1PressedThread);
		ID_ChangeFPThread5SpeedThread = uTTCOSg_AddThread(ChangeFPThread5SpeedThread, ONE_SECOND, RUN_ONCE);
	}

	SW1State = SW1Value;
	//printf("\n\n%d\n\n", SW1State);

}

extern volatile char ID_ChangeFPThread5SpeedThread = 0;
void ChangeFPThread5SpeedThread(void){
	uTTCOSg_DeleteThread(ID_FPThread4); //delete thread

	if(numSecondsSW1Held == 1){ //held between 1 and 2 seconds
		printf("\n\nheld 1-2 seconds\n\n");
		Lab0RuntimeFraction = Lab0RuntimeFraction * 0.5;
		ID_FPThread4 = uTTCOSg_AddThread(TaskFPThread4, NO_DELAY, Lab0RuntimeFraction * ONE_SECOND); //restart thread
	}
	else if(numSecondsSW1Held == 3){ //held between 3 and 4 seconds
		printf("\n\nheld 3-4 seconds\n\n");
		Lab0RuntimeFraction = Lab0RuntimeFraction * 2;
		ID_FPThread4 = uTTCOSg_AddThread(TaskFPThread4, NO_DELAY, Lab0RuntimeFraction * ONE_SECOND); //restart thread
	}
	else{
		printf("\n\nheld other seconds\n\n");
	}

	numSecondsSW1Held = 0; //reset num seconds

}

extern volatile char ID_CountSecondsSW1PressedThread = 0;
void CountSecondsSW1PressedThread(void){
	numSecondsSW1Held += 1;
}

extern volatile char ID_CheckSW5PressedReleased = 0;
void CheckSW5PressedReleased(void){
	static int SW5State = 0;
	unsigned char FPLEDValue = ~Read_GPIO_FrontPanelSwitches();
	unsigned char SW5Value = FPLEDValue & 0x10; //get value of SW2 only
	SW5Value = SW5Value >> 4;

	if(SW5Value == 0 && SW5State == 1){ //was previously on and now is off
		//printf("switch 5 pressed\n\n");
		ID_StoreSwitchValuesInArrayThread = uTTCOSg_AddThread(StoreSwitchValuesInArrayThread, NO_DELAY, RUN_ONCE);
	}

	SW5State = SW5Value;
	//printf("\n\n%d\n\n", SW1State);

}

extern volatile char ID_StoreSwitchValuesInArrayThread = 0;
void StoreSwitchValuesInArrayThread(void){
	static int index = 0;

	arrayValues[index] = (My_Read_REB_SW_ASM() & 0x0f00) >> 8;

	//printf("\n\n0x%x\n\n", arrayValues[index]);

	index += 1;

	if(index == 100){
		index = 0; //start rewriting over the array
	}
	else{
		REBArrayLength += 1; //length will increase until == 100
	}
}

extern volatile char ID_CheckSW3PressedReleasedThread = 0;
void CheckSW3PressedReleased(void){
	static int SW3State = 0;
	unsigned char FPLEDValue = ~Read_GPIO_FrontPanelSwitches();
	unsigned char SW3Value = FPLEDValue & 0x04; //get value of SW2 only
	SW3Value = SW3Value >> 2;


	if(SW3Value == 0 && SW3State == 1){ //was previously on and now is off
		if(ID_REBThread1 == 0){
			uTTCOSg_DeleteThread(ID_REBThread3);
			ID_REBThread3 = 0;
			ID_REBThread1 = uTTCOSg_AddThread(TaskREBThread1, NO_DELAY, 0.25 * ONE_SECOND);
		}
		else if(ID_REBThread3 == 0){
			uTTCOSg_DeleteThread(ID_REBThread1);
			ID_REBThread1 = 0;
			ID_REBThread3 = uTTCOSg_AddThread(DisplayREBSwitchValuesThread, NO_DELAY, 1.3 * ONE_SECOND);
		}
	}

	SW3State = SW3Value;
	//printf("\n\n%d\n\n", SW1State);
}

extern volatile char ID_REBThread3 = 0;
void DisplayREBSwitchValuesThread(void){
#define REB_LED_MASK 0x0fff
    //send a volatile message that you display this one
    //if 1 then use REBthread1 if 0 then use REBThread3 to display;
   // static int REB_1_OR_3 = 1;


	//printf("/n/nIN THIS THREAD\n\n");

	static int index = 0;

    unsigned short int previousREBLEDValue = My_Read_REB_SW_ASM();
    //need to pause REBThread1 as it displays on 4-7

    unsigned short int REBLEDValueNew = arrayValues[index];
    //how far do I shift this??
    REBLEDValueNew = (REBLEDValueNew << 12);//led values are now in 12-15;
    //we have all the previous values, have to zero the LED Values from before
//    previousREBLEDValue = previousREBLEDValue & REB_LED_MASK; //switch values 12-15 to zero
//    REBLEDValueNew = previousREBLEDValue | REBLEDValueNew; //keep all other values not in 12-15 constant
    My_Write_REB_LEDS_ASM(REBLEDValueNew);

    index += 1;

    if(index == REBArrayLength){
    	index = 0;
    }

}


#if 0
#warning "Once you have demonstrated uTTCOS  -- Comment out the following lines
// Set up uTTCOS path to function that this task needs to interact with
extern volatile char ID_Task_RemoveMeSoon_Print1;
extern volatile char ID_Task_RemoveMeSoon_Print2;
extern volatile char ID_Task_KillerOfPrintStatements_Hunting;
void Set_Up_NOT_START_RemoveMeSoonTasks(void) {
	printf("\n\nSET UP TASKS -- THEY DO NOT START IMMEDIATELY\n\n");
	ID_Task_RemoveMeSoon_Print1 = uTTCOSg_AddThread(Task_RemoveMeSoon_Print1, NO_DELAY, 0.75 * ONE_SECOND);
	ID_Task_RemoveMeSoon_Print2 = uTTCOSg_AddThread(Task_RemoveMeSoon_Print2, NO_DELAY, 2.5 * ONE_SECOND);
	ID_Task_KillerOfPrintStatements_Hunting = uTTCOSg_AddThread(KillerOfPrintStatements_Hunting, 8.5 * ONE_SECOND, RUN_ONCE);
	uTTCOSg_AddThread(TheEnd, 60 * ONE_SECOND, RUN_ONCE);
}

extern volatile char ID_Task_KillerOfPrintStatements;    // Set up uTTCOS path to function that this task needs to interact with
volatile char ID_Task_KillerOfPrintStatements_Hunting;   // Location to store this functions uTTCOS ID
void KillerOfPrintStatements_Hunting(void){
	printf("\nWhat story about an 'UNFRIENDLY GIANT' has the line 'FEE-FI-FO-FUM'?\n");
	printf(" I'm Looking for you -- RemoveMeSoon_Print1\n");
	printf("****  I am tired -- I am setting my big friend after you ***\n\n");
	ID_Task_KillerOfPrintStatements = uTTCOSg_AddThread(KillerOfPrintStatements, 5.0 * ONE_SECOND, RUN_ONCE);
}

extern volatile char ID_Task_RemoveMeSoon_Print1;		// Set up uTTCOS path to function that this task needs to interact with
volatile char ID_Task_KillerOfPrintStatements;			// Location to store this functions uTTCOS ID
void KillerOfPrintStatements(void) {
	printf("\n *** Found you my little precious  ***\n");
	printf("\n The next line is distressing -- READER DISCRETION IS ADVISED\n");
	printf(" HORRIBLE SOUNDS\n\n");

	uTTCOSg_DeleteThread(ID_Task_RemoveMeSoon_Print1);    // This stops the thread
}

extern volatile char ID_Task_RemoveMeSoon_Print2;
void TheEnd(void) {
	printf("\n *******************************\n");
	printf("The world is saved -- PRINT2 can go home and have a beer\n");
	uTTCOSg_DeleteThread(ID_Task_RemoveMeSoon_Print2);    // This stops the thread
}
#endif

