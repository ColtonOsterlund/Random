/*
 * Lab2.h
 *
 *  Created on: Oct 20, 2019
 *      Author: kfrie
 */

#ifndef LAB2_H_
#define LAB2_H_

#include "Example_faultyLED1_Thread.h"
#include "Example_faultyLED1_Thread.h"

#include <uTTCOSg2017/uTTCOSg.h>
#include <GPIO2017/ADSP_GPIO_interface.h>

#include <stdio.h>

#endif /* LAB2_H_ */
